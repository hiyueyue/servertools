#coding:utf-8
#数据库配置
statis_db = {
    "host" : "127.0.0.1",
    "port" : 3306,
    "username" : "root",
    "passwd" : "Lichisoft",
    "db" : "statis_db_1"
}

#日志路径
STATISTICS_LOG_PATH="/data/log/game_logic"


AllKey = "1970-01-01"
#DROP TABLE IF EXISTS data_statistics;
CREATE_DATA_STATISTICS = "CREATE TABLE IF NOT EXISTS data_statistics(\
	id INT UNSIGNED AUTO_INCREMENT,\
	type_id INT UNSIGNED not NULL,\
	descript VARCHAR(255) COMMENT '描述',\
    dau INT UNSIGNED not NULL COMMENT '日活',\
    dau_this INT UNSIGNED not NULL COMMENT '符合条件日活',\
    join_player INT UNSIGNED not NULL COMMENT '参与该活动的玩家数',\
    join_num INT UNSIGNED not NULL COMMENT '参与该活动的次数',\
    daily_new INT UNSIGNED not NULL COMMENT '当日新增',\
    remain_2 INT UNSIGNED not NULL DEFAULT 0 COMMENT '次留',\
    remain_3 INT UNSIGNED not NULL DEFAULT 0 COMMENT '3日留存',\
    remain_4 INT UNSIGNED not NULL DEFAULT 0 COMMENT '4日留存',\
    remain_5 INT UNSIGNED not NULL DEFAULT 0 COMMENT '5日留存',\
    remain_6 INT UNSIGNED not NULL DEFAULT 0 COMMENT '6日留存',\
    remain_7 INT UNSIGNED not NULL DEFAULT 0 COMMENT '7日留存',\
	date_time DATETIME DEFAULT '1970-01-01' COMMENT '日期',\
	UNIQUE KEY(id)\
) ENGINE=MyISAM DEFAULT CHARSET=utf8;"


#DROP TABLE IF EXISTS player_daily_achieve;
CREATE_PLAYER_DAILY_ACHIEVE= "CREATE TABLE IF NOT EXISTS player_daily_achieve(\
	id INT UNSIGNED AUTO_INCREMENT,\
	player_id INT UNSIGNED not NULL,\
    login TINYINT UNSIGNED not NULL DEFAULT 0 COMMENT '登陆',\
    pvp TINYINT UNSIGNED not NULL DEFAULT 0 COMMENT '竞技场',\
    boss TINYINT UNSIGNED not NULL DEFAULT 0 COMMENT '挑战boss副本',\
    cross_pvp TINYINT UNSIGNED not NULL DEFAULT 0 COMMENT '跨服争霸',\
    climb_tower TINYINT UNSIGNED not NULL DEFAULT 0 COMMENT '魂之试炼',\
    mineral_create TINYINT UNSIGNED not NULL DEFAULT 0 COMMENT '神之宝藏开采',\
    mineral_pvp TINYINT UNSIGNED not NULL DEFAULT 0 COMMENT '神之宝藏掠夺',\
    chapter_elite TINYINT UNSIGNED not NULL DEFAULT 0 COMMENT '精英副本',\
    equipment_upgrade TINYINT UNSIGNED not NULL DEFAULT 0 COMMENT '强化装备',\
    equipment_real_upgrade TINYINT UNSIGNED not NULL DEFAULT 0 COMMENT '装备升阶',\
    equipment_xilian TINYINT UNSIGNED not NULL DEFAULT 0 COMMENT '装备洗炼',\
    pet_upgrade_level TINYINT UNSIGNED not NULL DEFAULT 0 COMMENT '坐骑培养',\
    pet_upgrade_quality TINYINT UNSIGNED not NULL DEFAULT 0 COMMENT '坐骑升阶',\
    add_activity TINYINT UNSIGNED not NULL DEFAULT 0 COMMENT '购买体力',\
    activity_1_100 TINYINT UNSIGNED not NULL DEFAULT 0 COMMENT '体力消耗小于100',\
    activity_100_200 TINYINT UNSIGNED not NULL DEFAULT 0 COMMENT '体力消耗大于100小于200',\
    activity_200_300 TINYINT UNSIGNED not NULL DEFAULT 0 COMMENT '体力消耗大于200小于300',\
    activity_300 TINYINT UNSIGNED not NULL DEFAULT 0 COMMENT '体力消耗大于300',\
	date_time DATETIME DEFAULT '1970-01-01' COMMENT '日期',\
	UNIQUE KEY(id)\
) ENGINE=MyISAM DEFAULT CHARSET=utf8;"
