#coding:utf-8
__author__ = 'yuechen'
import MySQLdb
import sys
import time
import config
import datetime
from EnumType import *

class HistoryData:
    def __init__(self):
        self.PlayerDict = {} #map<player_id,map<type, vaule>>
        self.StatisticsDict = {} #map<type,num>
        self.StatisticsTotalDict = {} #map<type,total_num>
        self.TotalNum = 0

class TodayData:
    def __init__(self):
        self.PlayerDict= {} #map<player_id,num>
        self.TotalNum = 0
        self.DailyNewNum = 0
TodayDict = {} #map<type, TodayData>
HistoryDict = {} #map<day,HistoryData>
TodayPlayerData = {}#map <player_id,map<type, vaule>>

#HistoryStatisticsDict = {} #map<day, map<type,num>>
#HistoryStatisticsTotalDict = {} #map<day, map<type,total_num>>


#DayKey = []
#ToDay = ""

def process_log_data(player_id,type_id,num):
    if not TodayDict.has_key(type_id):
        TodayDict[type_id] = TodayData();
    TodayDict[type_id].PlayerDict[player_id] = TodayDict.get(type_id).PlayerDict.get(player_id,0) + num 
    if check_is_daily_new(player_id,type_id) == True:
        TodayDict[type_id].DailyNewNum = TodayDict.get(type_id).DailyNewNum + 1
    if not TodayPlayerData.has_key(player_id):
        TodayPlayerData[player_id] = {}
        TodayPlayerData[player_id][AUTO_ID]=0
    TodayPlayerData[player_id][type_id] = 1
    TodayDict[type_id].TotalNum = TodayDict.get(type_id).TotalNum + num 

def process_log(file_name):
    file_object = open(file_name)
    lines = file_object.readlines( )
    for line in lines:
        process_line(line)

    file_object.close()
    if not TodayDict.has_key(ACHIEVE_USE_ACTIVITY):
        TodayDict[ACHIEVE_USE_ACTIVITY] = TodayData()
    for player_id,value in TodayDict.get(ACHIEVE_USE_ACTIVITY).PlayerDict.items():
        if value < 100:
            process_log_data(player_id, ACHIEVE_USE_ACTIVITY_1_100, 1)
        elif value >=100 and value <200:
            process_log_data(player_id, ACHIEVE_USE_ACTIVITY_100_200, 1)
        elif value >=200 and value <300:
            process_log_data(player_id, ACHIEVE_USE_ACTIVITY_200_300, 1)
        elif value >=300:
            process_log_data(player_id, ACHIEVE_USE_ACTIVITY_300, 1)


    

def check_is_daily_new(player_id,type_id):
    if history_player_all.PlayerDict.has_key(player_id):
        map_value = history_player_all.PlayerDict[player_id]
        if map_value.has_key(type_id) and map_value[type_id] == 1:
            return False


    # todo update all player info
    if not history_player_all.PlayerDict.has_key(player_id):
        history_player_all.PlayerDict[player_id] = {}
    history_player_all.PlayerDict[player_id][type_id] = 1
    return True


def process_line(line):
    if line.find("AchievementStatistics") == -1:
        return
    tmp = line.split(',')
    if len(tmp) != 4:
        return
    player_id_arr = tmp[0].split('=')
    if len(player_id_arr) != 2:
        return
    player_id = player_id_arr[1]
    
    if player_id == "0":
        return 

    type_id_arr = tmp[1].split('=')
    if len(type_id_arr) != 2:
        return
    type_id = type_id_arr[1]
    
    num_arr = tmp[2].split('=')
    if len(num_arr) != 2:
        return
    num = num_arr[1]

    #print line
    #print "processline----",player_id," ",type_id," ",num

    #todo daily new 
    if type_id == ACHIEVE_LOGIN: 
        process_log_data(player_id, str(type_id), 1)
        if num >= 25:
            process_log_data(player_id, ACHIEVE_LOGIN_LV_25, 1)
        if num >= 28:
            process_log_data(player_id, ACHIEVE_LOGIN_LV_28, 1)
        if num >= 35:
            process_log_data(player_id, ACHIEVE_LOGIN_LV_35, 1)

    else:
        process_log_data(player_id, str(type_id), 1)
        

def replace_into_statis_db(day,type_id,remain,dateStr):
    #try:
    my_conn = MySQLdb.connect(host=config.statis_db["host"], port=config.statis_db["port"],
                  user=config.statis_db["username"], passwd=config.statis_db["passwd"],
                charset="utf8")
    sql = ("create database if not exists %s;" %config.statis_db["db"])
    cursor = my_conn.cursor()
    cursor.execute(sql)
    my_conn.select_db(config.statis_db["db"])
    sql = config.CREATE_DATA_STATISTICS 
    cursor.execute(sql)
    remain_field = "remain_" + str(day)
    sql = "update data_statistics set " + remain_field + "=%s where type_id=%s and date_time=%s" 
    cursor.execute(sql,(
        remain,
        type_id,
        dateStr))

    my_conn.commit()
    """
    except MySQLdb.Error, e:
        print("mysql error, msg=%s" %e)
    except Exception, e:
        print("other error, msg=%s" %e)
    """
    my_conn.close()

    pass

def insert_into_statis_db(type_id,dateStr):
    #try:
    #print "datestr:",dateStr
    #print len(str(dateStr))
    #print type_id, "================"
    my_conn = MySQLdb.connect(host=config.statis_db["host"], port=config.statis_db["port"],
                  user=config.statis_db["username"], passwd=config.statis_db["passwd"],
                charset="utf8")
    sql = ("create database if not exists %s;" %config.statis_db["db"])
    cursor = my_conn.cursor()
    cursor.execute(sql)
    my_conn.select_db(config.statis_db["db"])
    sql = config.CREATE_DATA_STATISTICS 
    cursor.execute(sql)
    dau_this = len(TodayPlayerData)
    if type_id == ACHIEVE_PVP: 
        dau_this = len(TodayDict[ACHIEVE_LOGIN_LV_25].PlayerDict) 
    elif type_id == ACHIEVE_CLIMB_TOWER: 
        dau_this = len(TodayDict[ACHIEVE_LOGIN_LV_28].PlayerDict)
    elif type_id == ACHIEVE_MINERAL_CREATE or type_id == ACHIEVE_MINERAL_PVP : 
        dau_this = len(TodayDict[ACHIEVE_LOGIN_LV_35].PlayerDict) 
    sql = "insert into data_statistics(type_id,descript,dau,dau_this,join_player,join_num,daily_new,date_time) values(%s,%s,%s,%s,%s,%s,%s,%s)"#values 
    cursor.execute(sql,(
        type_id,
        descMap.get(type_id,""),
        len(TodayPlayerData),
        dau_this,
        len(TodayDict[type_id].PlayerDict),
        TodayDict[type_id].TotalNum, 
        TodayDict[type_id].DailyNewNum, 
        str(dateStr)))

    my_conn.commit()
    """
    except MySQLdb.Error, e:
        print("mysql error, msg=%s" %e)
    except Exception, e:
        print("other error, msg=%s" %e)
        """
    my_conn.close()

    pass


def update_player_data_to_db(player_id,mapvalue,dateStr):
    #try:
    #print "@@@@@@@@@@@@@ update player_data_to_db",player_id,mapvalue,dateStr
    my_conn = MySQLdb.connect(host=config.statis_db["host"], port=config.statis_db["port"],
                  user=config.statis_db["username"], passwd=config.statis_db["passwd"],
                charset="utf8")
    sql = ("create database if not exists %s;" %config.statis_db["db"])
    cursor = my_conn.cursor()
    cursor.execute(sql)
    my_conn.select_db(config.statis_db["db"])
    sql = config.CREATE_PLAYER_DAILY_ACHIEVE   
    cursor.execute(sql)

    sql = "update player_daily_achieve set login=%s,\
    pvp=%s,\
    boss=%s,\
    cross_pvp=%s,\
    climb_tower=%s,\
    mineral_create=%s,\
    mineral_pvp=%s,\
    chapter_elite=%s,\
    equipment_upgrade=%s,\
    equipment_real_upgrade=%s,\
    equipment_xilian=%s,\
    pet_upgrade_level=%s,\
    pet_upgrade_quality=%s,\
    add_activity=%s,\
    activity_1_100=%s,\
    activity_100_200=%s,\
    activity_200_300=%s,\
    activity_300=%s where player_id=%s and date_time=%s"

    cursor.execute(sql,(
        mapvalue.get(ACHIEVE_LOGIN,0),
        mapvalue.get(ACHIEVE_PVP,0),
        mapvalue.get(ACHIEVE_BOSS,0),
        mapvalue.get(ACHIEVE_CROSS_PVP,0),
        mapvalue.get(ACHIEVE_CLIMB_TOWER,0),
        mapvalue.get(ACHIEVE_MINERAL_CREATE,0),
        mapvalue.get(ACHIEVE_MINERAL_PVP,0),
        mapvalue.get(ACHIEVE_CHAPTER_ELITE,0),
        mapvalue.get(ACHIEVE_EQUIPMENT_UPAGRADE,0),
        mapvalue.get(ACHIEVE_EQUIPMENT_REAL_UPGRADE,0),
        mapvalue.get(ACHIEVE_EQUIPMENT_XILIAN,0),
        mapvalue.get(ACHIEVE_PET_UPGRADE_LEVEL,0),
        mapvalue.get(ACHIEVE_PET_UPGRADE_QUALITY,0),
        mapvalue.get(ACHIEVE_ADD_ACTIVITY,0),
        mapvalue.get(ACHIEVE_USE_ACTIVITY_1_100,0),
        mapvalue.get(ACHIEVE_USE_ACTIVITY_100_200,0),
        mapvalue.get(ACHIEVE_USE_ACTIVITY_200_300,0),
        mapvalue.get(ACHIEVE_USE_ACTIVITY_300,0),
        player_id,
        dateStr))

    my_conn.commit()
    """
    except MySQLdb.Error, e:
        print("mysql error, msg=%s" %e)
    except Exception, e:
        print("other error, msg=%s" %e)
        """
    my_conn.close()

    pass


def insert_player_data_to_db(player_id,mapvalue,dateStr):
    #try:
    #print "@@@@@@@@@@@@@ insert player_data_to_db",player_id,mapvalue,dateStr
    my_conn = MySQLdb.connect(host=config.statis_db["host"], port=config.statis_db["port"],
                  user=config.statis_db["username"], passwd=config.statis_db["passwd"],
                charset="utf8")
    sql = ("create database if not exists %s;" %config.statis_db["db"])
    cursor = my_conn.cursor()
    cursor.execute(sql)
    my_conn.select_db(config.statis_db["db"])
    sql = config.CREATE_PLAYER_DAILY_ACHIEVE   
    cursor.execute(sql)
    sql = "insert into player_daily_achieve(\
    player_id,\
    login,\
    pvp,\
    boss,\
    cross_pvp,\
    climb_tower,\
    mineral_create,\
    mineral_pvp,\
    chapter_elite,\
    equipment_upgrade,\
    equipment_real_upgrade,\
    equipment_xilian,\
    pet_upgrade_level,\
    pet_upgrade_quality,\
    add_activity,\
    activity_1_100,\
    activity_100_200,\
    activity_200_300,\
    activity_300,\
    date_time \
    ) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    cursor.execute(sql,(
        player_id,
        mapvalue.get(ACHIEVE_LOGIN,0),
        mapvalue.get(ACHIEVE_PVP,0),
        mapvalue.get(ACHIEVE_BOSS,0),
        mapvalue.get(ACHIEVE_CROSS_PVP,0),
        mapvalue.get(ACHIEVE_CLIMB_TOWER,0),
        mapvalue.get(ACHIEVE_MINERAL_CREATE,0),
        mapvalue.get(ACHIEVE_MINERAL_PVP,0),
        mapvalue.get(ACHIEVE_CHAPTER_ELITE,0),
        mapvalue.get(ACHIEVE_EQUIPMENT_UPAGRADE,0),
        mapvalue.get(ACHIEVE_EQUIPMENT_REAL_UPGRADE,0),
        mapvalue.get(ACHIEVE_EQUIPMENT_XILIAN,0),
        mapvalue.get(ACHIEVE_PET_UPGRADE_LEVEL,0),
        mapvalue.get(ACHIEVE_PET_UPGRADE_QUALITY,0),
        mapvalue.get(ACHIEVE_ADD_ACTIVITY,0),
        mapvalue.get(ACHIEVE_USE_ACTIVITY_1_100,0),
        mapvalue.get(ACHIEVE_USE_ACTIVITY_100_200,0),
        mapvalue.get(ACHIEVE_USE_ACTIVITY_200_300,0),
        mapvalue.get(ACHIEVE_USE_ACTIVITY_300,0),
        dateStr))

    my_conn.commit()
    """
    except MySQLdb.Error, e:
        print("mysql error, msg=%s" %e)
    except Exception, e:
        print("other error, msg=%s" %e)
        """
    my_conn.close()
    #pass

def load_db_history_data(dateStr):
    history_data = HistoryData()
    #try:
    my_conn = MySQLdb.connect(host=config.statis_db["host"], port=config.statis_db["port"],
                  user=config.statis_db["username"], passwd=config.statis_db["passwd"],
                charset="utf8")
    my_conn.select_db(config.statis_db["db"])
    cursor = my_conn.cursor()
    sql = config.CREATE_PLAYER_DAILY_ACHIEVE   
    cursor.execute(sql)
    sql = "select " \
          "id,"\
          "player_id, " \
          "login," \
          "pvp," \
          "boss," \
          "cross_pvp," \
          "climb_tower," \
          "mineral_create," \
          "mineral_pvp," \
          "chapter_elite," \
          "equipment_upgrade," \
          "equipment_real_upgrade," \
          "equipment_xilian," \
          "pet_upgrade_level," \
          "pet_upgrade_quality," \
          "add_activity," \
          "activity_1_100," \
          "activity_100_200," \
          "activity_200_300," \
          "activity_300 " \
          " from player_daily_achieve where date_time = %s" 
    cursor.execute(sql,(dateStr))
    for row in cursor.fetchall():
        res = {}
        res[AUTO_ID] = row[0]
        player_id = row[1]
        res[ACHIEVE_LOGIN] = row[2]
        res[ACHIEVE_PVP] = row[3]
        res[ACHIEVE_BOSS] = row[4]
        res[ACHIEVE_CROSS_PVP] = row[5]
        res[ACHIEVE_CLIMB_TOWER] = row[6]
        res[ACHIEVE_MINERAL_CREATE] = row[7]
        res[ACHIEVE_MINERAL_PVP] = row[8]
        res[ACHIEVE_CHAPTER_ELITE] = row[9]
        res[ACHIEVE_EQUIPMENT_UPAGRADE] = row[10]
        res[ACHIEVE_EQUIPMENT_REAL_UPGRADE] = row[11]
        res[ACHIEVE_EQUIPMENT_XILIAN] = row[12]
        res[ACHIEVE_PET_UPGRADE_LEVEL] = row[13]
        res[ACHIEVE_PET_UPGRADE_QUALITY] = row[14]
        res[ACHIEVE_ADD_ACTIVITY] = row[15]
        res[ACHIEVE_USE_ACTIVITY_1_100] = row[16]
        res[ACHIEVE_USE_ACTIVITY_100_200] = row[17]
        res[ACHIEVE_USE_ACTIVITY_200_300] = row[18]
        res[ACHIEVE_USE_ACTIVITY_300] = row[19]
        #HistoryDict[dateStr][player_id] = res
        history_data.PlayerDict[player_id] = res
        #print "$$$$$$$$$$$$$$$$$$load player data from db:",player_id,res 
        
        #handle_event(log_time, event_id, field)
        """
    except MySQLdb.Error, e:
        print("mysql error, msg=%s" %e)
    except Exception, e:
        print("other error, msg=%s" %e)
        """
    my_conn.close()
    return history_data

        
def generate_day_key():
    global ToDay
    ToDay = (datetime.date.today() - datetime.timedelta(days=(1 + n))).strftime('%Y-%m-%d')
    print "yestoday ",ToDay 
    """
    Before1Day = (datetime.date.today() - datetime.timedelta(days=2)).strftime('%Y-%m-%d')
    Before2Day = (datetime.date.today() - datetime.timedelta(days=3)).strftime('%Y-%m-%d')
    Before3Day = (datetime.date.today() - datetime.timedelta(days=4)).strftime('%Y-%m-%d')
    Before4Day = (datetime.date.today() - datetime.timedelta(days=5)).strftime('%Y-%m-%d')
    Before5Day = (datetime.date.today() - datetime.timedelta(days=6)).strftime('%Y-%m-%d')
    Before6Day = (datetime.date.today() - datetime.timedelta(days=7)).strftime('%Y-%m-%d')
    Before7Day = (datetime.date.today() - datetime.timedelta(days=8)).strftime('%Y-%m-%d')
    """

    global DayKey
    DayKey = []
    #昨天，前天，....前7天
    for i in range(1,7):
        print "DayKey",i," ",(datetime.date.today() - datetime.timedelta(days=(i + 1 + n))).strftime('%Y-%m-%d')
        DayKey.append((datetime.date.today() - datetime.timedelta(days=(i + 1 + n))).strftime('%Y-%m-%d'))

    
def caculate_liucun(history_data):
    for player_id, res_map in history_data.PlayerDict.items():
        for type_id, value in res_map.items():
            if value > 0:
                history_data.StatisticsTotalDict[type_id] = history_data.StatisticsTotalDict.get(type_id,0) + 1 
                if not TodayDict.has_key(type_id):
                    TodayDict[type_id] = TodayData()
                if TodayDict.get(type_id).PlayerDict.has_key(str(player_id)):
                    history_data.StatisticsDict[type_id] = history_data.StatisticsDict.get(type_id,0) + 1 


    """
    print "caculate liucun ==================="
    for type_id,data in TodayDict.items():
        print type_id, data.PlayerDict
    print history_data.PlayerDict
    print history_data.StatisticsDict
    print history_data.StatisticsTotalDict
    """
    return history_data
                    

        

def process_data():
    global n
    n=0
    yesterday = datetime.date.today() - datetime.timedelta(days=1 + n)
    #time_str = time.strftime('%Y%m%d')
    file_name = config.STATISTICS_LOG_PATH + "/statlog." + yesterday.strftime('%Y%m%d')
    print "============"
    print file_name

    print "step 1 ==============process yestorday's log and daily satatis"
    generate_day_key()
    global history_player_all
    history_player_all = load_db_history_data(config.AllKey)

    process_log(file_name)

    print "step 2 ==============load 7days history data and caculate liucun"
    for i in range(0,6):
        print "load history data", DayKey[i];
        history_data = load_db_history_data(DayKey[i])
        history_data1 = caculate_liucun(history_data)
        # caculate liucun and save to db
        print "history_data1==============="
        print history_data1.StatisticsDict
        print history_data1.StatisticsTotalDict
        for type_id, num  in history_data1.StatisticsTotalDict.items():
            if history_data1.StatisticsTotalDict.get(type_id,0) != 0:
                remain = history_data1.StatisticsDict.get(type_id,0) * 100 / history_data1.StatisticsTotalDict.get(type_id,0)
                print "****remain*** Date:",DayKey[i],"i:",i,"type_id:",type_id,"num:",history_data1.StatisticsDict.get(type_id,0),"total_num:",history_data1.StatisticsTotalDict.get(type_id,0),"remain:",remain
                replace_into_statis_db(i + 2,type_id,remain,DayKey[i]);

        """
        for type_id in range(104,108):
            if history_data1.StatisticsTotalDict.get(type_id,0) != 0:
                remain = history_data1.StatisticsDict.get(type_id,0) * 100 / history_data1.StatisticsTotalDict.get(type_id,0)
                print "****remain*** Date:",DayKey[i],"i:",i,"type_id:",type_id,"num:",history_data1.StatisticsDict.get(type_id,0),"total_num:",history_data1.StatisticsTotalDict.get(type_id,0),"remain:",remain
                replace_into_statis_db(i + 1,type_id,remain,DayKey[i]);
                """


    print "step 3 =============save yestoday tata to db"  

    for type_id, today_data in TodayDict.items():
        if type_id == AUTO_ID or type_id == ACHIEVE_LOGIN_LV_25 or type_id == ACHIEVE_LOGIN_LV_28 or type_id == ACHIEVE_LOGIN_LV_35:
            continue
        print "--------type_id:",type_id,today_data
        insert_into_statis_db(type_id,yesterday)

    for player_id,map_value in TodayPlayerData.items():
        insert_player_data_to_db(player_id,map_value,ToDay)

    print "step 4 =============update player all data to db"  
    for player_id, map_value in history_player_all.PlayerDict.items():
        if map_value.get(AUTO_ID,0) != 0:
            update_player_data_to_db(player_id,map_value,config.AllKey )
        else:
            insert_player_data_to_db(player_id,map_value,config.AllKey)


if __name__ == '__main__':
    process_data()

