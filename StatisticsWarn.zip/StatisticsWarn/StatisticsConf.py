#coding:utf-8
#元宝
MAX_YUANBAO=1
#元宝不包括充值
MAX_YUANBAO_NOT_PAY=1
#銅币
MAX_TONGBI=1
#銅币不包括炼金
MAX_TONGBI_NOT_ALCHEMY=1
#强化石
MAX_QIANGHUASHI=1
#强化石不包括商城
MAX_QIANGHUASHI_NOT_BUY=1
#灵魂石
MAX_LINGHUNSHI=1
#灵魂石不包括商城
MAX_LINGHUNSHI_NOT_BUY=1
#洗炼石
MAX_XILIANSHI=1
#洗炼石不包括商城
MAX_XILIANSHI_NOT_BUY=1
#神兵碎片
MAX_SHENBING=1


mailto_list=['yuechen@lichisoft.com','569116141@qq.com']
