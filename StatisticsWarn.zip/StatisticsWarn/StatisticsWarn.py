#coding:utf-8
import sys
import StatisticsConf
import MailClient
import time

yuanbao_map = {}
yuanbao_buy_map = {}
tongbi_map = {}
tongbi_buy_map = {}
qianghuashi_map = {}
qianghuashi_shop_map = {}
xilianshi_map = {}
xilianshi_shop_map = {}
shenbin_map = {}
linghunshi_map = {}
linghunshi_shop_map = {}
g_server_id = 0


def process_log(file_name):
    file_object = open(file_name)
    lines = file_object.readlines( )
    for line in lines:
        process_line(line)



def process_line(line):
    if line.find("Statistics,") == -1:
        return
    tmp = line.split(',')
    player_str = tmp[len(tmp) - 1]
    player_arr = player_str.split('=')
    if len(player_arr) < 2:
        return
    if len(player_arr[1]) < 1:
        return
    player_id = player_arr[1][:-1]
    num_arr = tmp[2].split('=')
    num = int(num_arr[1])
    print "player_id:",player_id
    print "num:",num
    if tmp[1].find("item added") != -1:
    #增加物品
        template_id_arr = tmp[3].split('=')
        template_id = int(template_id_arr[1])
        print "template_id:",template_id
        if template_id == 2: #元宝
            yuanbao_map[player_id] = yuanbao_map.get(player_id,0) + num
        elif template_id == 1: #銅币
            tongbi_map[player_id] = tongbi_map.get(player_id,0) + num
        elif template_id == 101: #强化石
            qianghuashi_map[player_id] = qianghuashi_map.get(player_id,0) + num
        elif template_id == 1101: #洗炼石
            xilianshi_map[player_id] = xilianshi_map.get(player_id,0) + num
        elif template_id >=121 and template_id <=130: #神兵
            shenbin_map[player_id] = shenbin_map.get(player_id,0) + num
        elif template_id >=801 and template_id <=805: #灵魂石
            linghunshi_map[player_id] = linghunshi_map.get(player_id,0) + num
    elif tmp[1].find("Alchemy Tongbin Added") != -1:#炼金
        print "Alchemy Tongbin Added"
        tongbi_buy_map[player_id] = tongbi_buy_map.get(player_id,0) + num
    elif tmp[1].find("Yuanbao added For Buy") != -1:
        yuanbao_buy_map[player_id] = yuanbao_buy_map.get(player_id,0) + num  
    elif tmp[1].find("ShopBuyItem") != -1:
        item_id_arr = tmp[3].split("=")
        item_id = int(item_id_arr[1])
        if item_id == 101: #强化石
            qianghuashi_shop_map[player_id] = qianghuashi_shop_map.get(player_id,0) + num
        elif item_id == 1101: #洗炼石
            xilianshi_shop_map[player_id] = xilianshi_shop_map.get(player_id,0) + num
        elif item_id >=801 and item_id <=805: #灵魂石
            linghunshi_shop_map[player_id] = linghunshi_shop_map.get(player_id, 0) + num

def GenerateWarningList():
    global g_is_send 
    global content
    content = ""
    g_is_send = 0
    content = content + "当日元宝获得超过 " + str(StatisticsConf.MAX_YUANBAO) + ' 的用户\n'
    content = content + "player_id,元宝\n"
    for player_id,value in yuanbao_map.items(): 
        if value >= StatisticsConf.MAX_YUANBAO:
            g_is_send = 1
            record = str(player_id) + ',' + str(value) + '\n' 
            content = content + record

    content = content + "当日元宝获得超过 " + str(StatisticsConf.MAX_YUANBAO_NOT_PAY) + ' 的用户(不包括充值)\n'
    content = content + "player_id,元宝\n"
    for player_id,value in yuanbao_map.items(): 
        result = value - yuanbao_buy_map.get(player_id,0)
        if result >= StatisticsConf.MAX_YUANBAO_NOT_PAY:
            g_is_send = 1
            record = str(player_id) + ',' + str(result) + '\n' 
            content = content + record

    content = content + "当日铜币获得超过 " + str(StatisticsConf.MAX_TONGBI) + ' 的用户\n'
    content = content + "player_id,铜币\n"
    for player_id,value in tongbi_map.items(): 
        if value >= StatisticsConf.MAX_TONGBI:
            g_is_send = 1
            record = str(player_id) + ',' + str(value) + '\n' 
            content = content + record
    
    content = content + "当日铜币获得超过 " + str(StatisticsConf.MAX_TONGBI) + ' 的用户(不包括炼金)\n'
    content = content + "player_id,铜币\n"
    for player_id,value in tongbi_map.items(): 
        result = value - tongbi_buy_map.get(player_id,0)
        if result >= StatisticsConf.MAX_TONGBI_NOT_ALCHEMY:
            g_is_send = 1
            record = str(player_id) + ',' + str(result) + '\n' 
            content = content + record

    content = content + "当日获得的强化石的数量超过 " + str(StatisticsConf.MAX_QIANGHUASHI) + ' 的用户\n'
    content = content + "player_id,强化石\n"
    for player_id,value in qianghuashi_map.items(): 
        if value >= StatisticsConf.MAX_QIANGHUASHI:
            g_is_send = 1
            record = str(player_id) + ',' + str(value) + '\n' 
            content = content + record

    content = content + "当日获得的强化石的数量超过 " + str(StatisticsConf.MAX_QIANGHUASHI_NOT_BUY) + ' 的用户(不包括商城购买)\n'
    content = content + "player_id,强化石\n"
    for player_id,value in qianghuashi_map.items(): 
        result = value - qianghuashi_shop_map.get(player_id,0)
        if result >= StatisticsConf.MAX_QIANGHUASHI_NOT_BUY:
            g_is_send = 1
            record = str(player_id) + ',' + str(result) + '\n' 
            content = content + record

    content = content + "当日获得的灵魂石的数量超过 " + str(StatisticsConf.MAX_LINGHUNSHI) + ' 的用户\n'
    content = content + "player_id,灵魂石\n"
    for player_id,value in linghunshi_map.items(): 
        if value >= StatisticsConf.MAX_LINGHUNSHI:
            g_is_send = 1
            record = str(player_id) + ',' + str(value) + '\n' 
            content = content + record

    content = content + "当日获得的灵魂石的数量超过 " + str(StatisticsConf.MAX_LINGHUNSHI_NOT_BUY) + ' 的用户(不包括商城购买)\n'
    content = content + "player_id,灵魂石\n"
    for player_id,value in linghunshi_map.items(): 
        result = value - linghunshi_shop_map.get(player_id,0)
        if result >=StatisticsConf.MAX_LINGHUNSHI_NOT_BUY:
            g_is_send = 1
            record = str(player_id) + ',' + str(result) + '\n' 
            content = content + record


    content = content + "当日获得的洗练石的数量超过 " + str(StatisticsConf.MAX_XILIANSHI) + ' 的用户\n'
    content = content + "player_id,洗练石\n"
    for player_id,value in linghunshi_map.items(): 
        if value >= StatisticsConf.MAX_XILIANSHI:
            g_is_send = 1
            record = str(player_id) + ',' + str(value) + '\n' 
            content = content + record

    content = content + "当日获得的洗练石的数量超过 " + str(StatisticsConf.MAX_XILIANSHI_NOT_BUY) + '的用户(不包括商城购买)\n'
    content = content + "player_id,洗练石\n"
    for player_id,value in linghunshi_map.items(): 
        result = value - linghunshi_shop_map.get(player_id,0)
        if result >= StatisticsConf.MAX_XILIANSHI_NOT_BUY:
            g_is_send = 1
            record = str(player_id) + ',' + str(result) + '\n' 
            content = content + record

    content = content + "当日获得的所有神兵碎片的数量超过 " + str(StatisticsConf.MAX_SHENBING) + ' 的用户\n'
    content = content + "player_id,神兵碎片\n"
    for player_id,value in linghunshi_map.items(): 
        if value >= StatisticsConf.MAX_SHENBING:
            g_is_send = 1
            record = str(player_id) + ',' + str(value) + '\n' 
            content = content + record


if __name__ == '__main__':

    time_str = time.strftime('%Y%m%d')
    file_name = "../statlog." + time_str
    process_log(file_name)
    GenerateWarningList()
    title = "DataWarning"
    print "============"
    print content 
    print "send",g_is_send
    if g_is_send == 1:
        MailClient.send_mail(StatisticsConf.mailto_list,title,content)
        result_file = "warning." + time_str
        file_object = open(result_file,'w')
        file_object.write(content)
        file_object.close()
